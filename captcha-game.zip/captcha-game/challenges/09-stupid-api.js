/* 9 — The 'stupidest API' finale. Disabled (empty card) for now: flip ENABLED to true to turn it on. */
(function(){
const ENABLED=false;
const def=({
  css:`
body.glitch #card{animation:hue 1.2s linear infinite}
@keyframes hue{to{filter:hue-rotate(360deg)}}
.term{background:#111;color:#7CFC9a;font:11px/1.35 ui-monospace,Menlo,Consolas,monospace;height:120px;overflow:hidden;padding:6px;border-radius:4px;white-space:pre-wrap;word-break:break-all}
.bar{height:10px;background:#eee;border-radius:5px;margin-top:8px;overflow:hidden}
.bar i{display:block;height:100%;width:0;background:var(--blue)}
.nest{border:2px solid #bbb;background:#fafafa;padding:5px;margin-top:5px;font-size:11px;transform-origin:top center}
.nest:nth-child(odd){background:#eef5ff}
`,
  title:'Verification 9 of ∞',sub:'Verifying…',render(b){
  const lines=[
    ()=>`GET /api/v1/human?id=you  →  {"human":"maybe","confidence":${(Math.random()/1000).toFixed(5)},"vibes":"off"}`,
    ()=>`POST /api/v1/captcha/verify  →  418 {"message":"I'm a teapot. You are not."}`,
    ()=>`{"solved":"kinda","next":"captcha/${rnd(10,9999)}","after":"captcha/${rnd(10,9999)}"}`,
    ()=>`{"error":"mouse movement was too confident"}`,
    ()=>`{"human":false,"reason":"blinked at the wrong time"}`,
    ()=>`{"latency":"-${rnd(5,90)}ms","note":"we verified you before you asked"}`,
    ()=>`{"fingerprint":"smells like a robot","cookies":"stale"}`,
    ()=>`{"status":"NaN","retry_after":"yesterday"}`,
    ()=>`{"human_score":${rnd(-9,9)},"required":"banana"}`,
    ()=>`{"message":"please prove you are human to prove you are human"}`,
    ()=>`GET /api/v1/sadness  →  200 {"your_attempt":"noted"}`,
  ];
  const term=el('div',{className:'term'});
  const bar=el('div',{className:'bar'},el('i'));
  const lab=el('div',{className:'hint',textContent:'Verifying…'});
  const nest=el('div');
  b.append(term,bar,lab,nest);
  let req=1,pct=0,n=0,tilt=0,deepest=nest;
  const buf=[];
  const i1=setInterval(()=>{
    buf.push(`#${String(req++).padStart(5,'0')} ${lines[rnd(0,lines.length-1)]()}`);if(buf.length>8)buf.shift();
    term.textContent=buf.join('\n');
    pct+=rnd(3,11);
    if(pct>=99){pct=rnd(4,30);lab.textContent=`Server says: lol no. Retrying (attempt ${req})…`}else lab.textContent=`Verifying… ${pct}%`;
    bar.firstChild.style.width=pct+'%';
    $('#title').textContent=`Verification ${9+Math.floor(req/12)} of ∞`;
  },220);
  const i2=setInterval(()=>{
    n++;
    const d=el('div',{className:'nest'});
    d.innerHTML=`<b>Captcha ${9+n} of ∞</b> — prove you're human to continue proving you're human`;
    deepest.append(d);deepest=d;
    tilt=Math.min(tilt+.5,4);
    $('#card').style.transform=`rotate(${(Math.random()*2-1)*tilt}deg)`;
    beep(200+n*25,.05);
    if(n===6)document.body.classList.add('glitch');
  },1600);
  return()=>{clearInterval(i1);clearInterval(i2);document.body.classList.remove('glitch');$('#card').style.transform=''};
}});
if(ENABLED)registerChallenge(9,def);
else registerChallenge(9,{title:'Verification',sub:'',render(){}});
})();
