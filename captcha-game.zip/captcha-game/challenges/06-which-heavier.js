/* 6 — which is heavier (MEDIUM) */
registerChallenge(6,{
  css:`
.scalerow{display:flex;justify-content:space-around;margin-top:20px}
.obj{font-size:60px;width:110px;height:110px;background:#f4f4f4;border:1px solid #ccc;border-radius:6px;cursor:pointer}
.beam{margin:16px auto 0;width:260px;height:8px;background:#444;border-radius:4px;transition:transform .5s;transform-origin:50% 50%}
.base{margin:0 auto;width:0;height:0;border-left:26px solid transparent;border-right:26px solid transparent;border-bottom:50px solid #666}
`,
  title:'Click the object that would tip the scale',sub:'Verification',render(b,{pass,fail}){
  const sq={e:'🐿️',w:.5},pr={e:'🍐',w:.2};
  const sides=shuffle([sq,pr]);
  const h=sides[0].w>sides[1].w?0:1;
  const beam=el('div',{className:'beam'});
  const row=el('div',{className:'scalerow'});
  let busy=false;
  sides.forEach((o,i)=>{
    const btn=el('button',{className:'obj',textContent:o.e});
    btn.onclick=()=>{if(busy)return;busy=true;beam.style.transform=`rotate(${h?9:-9}deg)`;setTimeout(()=>i===h?pass():fail('Incorrect. Try again.'),650)};
    row.append(btn);
  });
  b.append(el('div',{className:'big',textContent:'Click the object that would tip the scale'}),row,beam,el('div',{className:'base'}));
}});
