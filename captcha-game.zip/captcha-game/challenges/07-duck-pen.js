/* 7 — escaped ducks: drag them back into the pen (HARD) */
registerChallenge(7,{
  css:`
.duck{position:fixed;font-size:34px;cursor:grab;touch-action:none;z-index:50;user-select:none;line-height:1}
.pond{background:#e8d9ae;height:210px;border:4px dashed #8b5a2b;border-radius:8px;position:relative}
.penlabel{position:absolute;inset:0;display:grid;place-items:center;font-weight:700;font-size:26px;letter-spacing:4px;color:rgba(139,90,43,.28);pointer-events:none}
`,
  title:'Put the escaped ducks back in the pen',sub:'Verification',render(b,{pass,fail}){
  const N=12;let inPen=0,raf;const timers=[];
  const cnt=el('div',{className:'big',textContent:`In the pen: ${N}/${N}`});
  const pond=el('div',{className:'pond'});pond.innerHTML='<div class="penlabel">DUCK PEN</div>';
  b.append(cnt,pond,el('div',{className:'hint',textContent:'Drag each duck back into the pen.'}));
  const pen=()=>pond.getBoundingClientRect();
  const inside=(x,y)=>{const r=pen();return x>r.left+4&&x<r.right-4&&y>r.top+4&&y<r.bottom-4};
  const upd=()=>{cnt.textContent=`In the pen: ${inPen}/${N}`};
  const clamp=(v,lo,hi)=>Math.max(lo,Math.min(hi,v));
  const rv=o=>{o.a=Math.random()*Math.PI*2;o.spd=(.5+Math.random()*1.3)*(o.penned?.35:1);o.vx=Math.cos(o.a)*o.spd;o.vy=Math.sin(o.a)*o.spd};
  const ducks=[];
  for(let i=0;i<N;i++){
    const d=el('span',{className:'duck',textContent:'🦆'});
    const o={d,x:0,y:0,penned:true,drag:null};
    const pr=pen();o.x=rnd(pr.left+10,pr.right-50);o.y=rnd(pr.top+10,pr.bottom-50);inPen++;
    rv(o);
    timers.push(setTimeout(()=>{
      if(o.penned&&!o.drag){
        o.penned=false;o.escaped=true;inPen--;upd();
        const q=pen(),a=Math.atan2(o.y+20-(q.top+q.height/2),o.x+20-(q.left+q.width/2))+(Math.random()-.5);
        o.spd=1+Math.random()*1.4;o.vx=Math.cos(a)*o.spd;o.vy=Math.sin(a)*o.spd;beep(300+i*30,.05);
      }
    },500+i*260+rnd(0,200)));
    d.onpointerdown=e=>{e.preventDefault();d.setPointerCapture(e.pointerId);o.drag=[e.clientX-o.x,e.clientY-o.y];o.escaped=true;if(o.penned){o.penned=false;inPen--;upd()}d.style.cursor='grabbing';d.style.zIndex=60;beep(520,.04)};
    d.onpointermove=e=>{if(o.drag){o.x=e.clientX-o.drag[0];o.y=e.clientY-o.drag[1]}};
    d.onpointerup=d.onpointercancel=()=>{
      if(!o.drag)return;o.drag=null;d.style.cursor='grab';d.style.zIndex=50;
      if(inside(o.x+20,o.y+20)){o.penned=true;inPen++;rv(o);beep(700,.06);upd();if(inPen===N&&ducks.every(x=>x.escaped))pass()}else rv(o);
    };
    document.body.append(d);ducks.push(o);
  }
  const tick=()=>{
    const r=pen();
    ducks.forEach(o=>{
      if(!o.drag){
        if(Math.random()<.012)rv(o);
        o.x+=o.vx;o.y+=o.vy;
        if(o.penned){
          if(o.x<r.left+3||o.x>r.right-43)o.vx*=-1;
          if(o.y<r.top+3||o.y>r.bottom-43)o.vy*=-1;
          o.x=clamp(o.x,r.left+3,r.right-43);o.y=clamp(o.y,r.top+3,r.bottom-43);
        }else{
          if(o.x<0||o.x>innerWidth-40)o.vx*=-1;
          if(o.y<0||o.y>innerHeight-40)o.vy*=-1;
          o.x=clamp(o.x,0,innerWidth-40);o.y=clamp(o.y,0,innerHeight-40);
        }
      }
      o.d.style.left=o.x+'px';o.d.style.top=o.y+'px';o.d.style.transform=`scaleX(${o.vx<0?-1:1})`;
    });
    raf=requestAnimationFrame(tick);
  };
  tick();
  return()=>{cancelAnimationFrame(raf);timers.forEach(clearTimeout);ducks.forEach(o=>o.d.remove())};
}});
