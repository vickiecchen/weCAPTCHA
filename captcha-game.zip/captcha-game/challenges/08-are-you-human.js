/* 8 — are you human? (HARD) */
registerChallenge(8,{
  css:`
.rc{position:absolute;width:220px;height:58px;background:#f9f9f9;border:1px solid #d3d3d3;border-radius:3px;display:flex;align-items:center;gap:12px;padding:0 12px;font-size:15px;cursor:pointer;transition:left .1s,top .1s,transform .1s;box-shadow:0 0 4px rgba(0,0,0,.08)}
.rc .cb{width:26px;height:26px;border:2px solid #c1c1c1;background:#fff;border-radius:2px;flex:none}
`,
  title:'Are you human?',sub:'Verification',render(b,{pass,fail}){
  const prompts=[['Are you human?','I\'m not a robot'],['Are you sure?','Yes I\'m sure'],['Are you sure sure?','Yes. Sure sure.'],['Really? Look me in the eye.','I\'m. Not. A. Robot.']];
  const limits=[3,5,7,10];
  let stage=0,dodges=0,scale=1;
  const area=el('div');area.style.cssText='position:relative;height:270px';
  const q=el('div',{className:'big'});
  const box=el('div',{className:'rc'});
  box.append(el('div',{className:'cb'}),el('span'));
  const lab=box.lastChild;
  const move=()=>{const x=rnd(0,100),y=rnd(40,200);box.style.left=x+'px';box.style.top=y+'px'};
  const setStage=()=>{q.textContent=prompts[stage][0];lab.textContent=prompts[stage][1];dodges=0;scale=1;box.style.transform='scale(1)';move()};
  const dodge=()=>{if(dodges<limits[stage]){dodges++;scale*=.93;box.style.transform=`scale(${scale})`;move();beep(300+dodges*40,.04)}};
  box.onpointerenter=dodge;
  box.onclick=()=>{if(dodges<limits[stage])return dodge();stage++;if(stage>=prompts.length)return pass();beep(660,.08);setStage()};
  area.append(box);b.append(q,area);setStage();
}});
