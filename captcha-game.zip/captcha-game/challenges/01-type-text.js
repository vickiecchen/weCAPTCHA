/* 1 — enter the numbers (EASY) */
registerChallenge(1,{title:'Type the text you see',sub:'Verification',render(b,{pass,fail}){
  const code=String(rnd(1000,9999));
  const c=el('canvas',{width:340,height:90});c.style.cssText='width:100%;border:1px solid #ccc;display:block';
  const x=c.getContext('2d');
  x.fillStyle='#8a8776';x.fillRect(0,0,340,90);
  for(let i=0;i<500;i++){x.fillStyle=`rgba(${rnd(0,255)},${rnd(0,255)},${rnd(0,255)},.15)`;x.fillRect(rnd(0,340),rnd(0,90),rnd(1,6),rnd(1,6))}
  x.font='italic bold 52px Georgia,serif';x.textBaseline='middle';
  [...code].forEach((ch,i)=>{x.save();x.translate(85+i*50,45+rnd(-6,6));x.rotate(rnd(-18,18)*Math.PI/180);x.fillStyle='#1a1a1a';x.fillText(ch,-14,0);x.restore()});
  for(let i=0;i<3;i++){x.strokeStyle='rgba(0,0,0,.35)';x.beginPath();x.moveTo(0,rnd(0,90));x.bezierCurveTo(100,rnd(0,90),200,rnd(0,90),340,rnd(0,90));x.stroke()}
  const inp=el('input',{placeholder:'Type the text',inputMode:'numeric',maxLength:6,type:'text'});
  const btn=el('button',{className:'v',textContent:'Submit'});
  const go=()=>inp.value.trim()===code?pass():fail('Incorrect. Try again.');
  btn.onclick=go;inp.onkeydown=e=>{if(e.key==='Enter')go()};
  b.append(c,inp,btn);setTimeout(()=>inp.focus(),60);
}});
