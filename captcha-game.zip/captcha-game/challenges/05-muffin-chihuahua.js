/* 5 — muffin or chihuahua (MEDIUM) — drop photos in img/05/muffin1..8.jpg and img/05/chi1..8.jpg to use real ones */
registerChallenge(5,{title:'Select all chihuahuas',sub:'Verification',render(b,{pass,fail}){
  const items=shuffle([...Array(8).keys()].map(i=>({dog:1,i:i+1})).concat([...Array(8).keys()].map(i=>({dog:0,i:i+1}))));
  const g=el('div',{className:'grid'});g.style.gridTemplateColumns='repeat(4,1fr)';
  const sel=new Set();
  items.forEach((it,idx)=>{
    const t=el('button',{className:'tile'});
    const emoji=it.dog?'🐶':'🧁';
    const img=el('img',{src:`img/05/${it.dog?'chi':'muffin'}${it.i}.jpg`,alt:''});
    img.onerror=()=>{img.replaceWith(el('span',{textContent:emoji}))};
    t.append(img);
    t.onclick=()=>{sel.has(idx)?sel.delete(idx):sel.add(idx);t.classList.toggle('sel')};
    g.append(t);
  });
  const btn=el('button',{className:'v',textContent:'Verify'});
  btn.onclick=()=>items.every((it,i)=>!!it.dog===sel.has(i))?pass():fail('Incorrect. Try again.');
  b.append(g,btn);
}});
