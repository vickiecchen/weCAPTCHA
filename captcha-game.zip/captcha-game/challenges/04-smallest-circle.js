/* 4 — move the thing out of the way (MEDIUM) */
registerChallenge(4,{title:'Click the smallest circle',sub:'Verification',render(b,{pass,fail}){
  const area=el('div');area.style.cssText='position:relative;height:360px';
  const small=rnd(0,3),others=shuffle([64,52,40]);let k=0;
  const xs=[45,125,205,285],CY=180;
  xs.forEach((cx,i)=>{
    const s=i===small?12:others[k++];
    const d=el('div');d.style.cssText=`position:absolute;border-radius:50%;background:#2a2af0;width:${s}px;height:${s}px;left:${cx-s/2}px;top:${CY-s/2}px;cursor:pointer`;
    d.onclick=()=>i===small?pass():fail('Incorrect. Try again.');
    area.append(d);
  });
  const blob=el('div',{textContent:'Sponsored'});
  blob.style.cssText=`position:absolute;width:96px;height:96px;border-radius:50%;background:#ffd23f;display:grid;place-items:center;font-weight:700;font-size:13px;left:${xs[small]-48}px;top:${CY-48}px;cursor:grab;z-index:5;touch-action:none;box-shadow:0 2px 6px rgba(0,0,0,.25)`;
  let off=null;
  blob.onpointerdown=e=>{blob.setPointerCapture(e.pointerId);off=[e.clientX-blob.offsetLeft,e.clientY-blob.offsetTop];blob.style.cursor='grabbing'};
  blob.onpointermove=e=>{if(!off)return;blob.style.left=e.clientX-off[0]+'px';blob.style.top=e.clientY-off[1]+'px'};
  blob.onpointerup=()=>{off=null;blob.style.cursor='grab'};
  area.append(blob);
  b.append(area);
}});
