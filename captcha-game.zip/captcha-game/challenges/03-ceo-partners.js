/* 3 — CEO in the middle, 8 people around (MEDIUM). Photos: img/03/ceo.jpg and img/03/p1..p8.jpg (emoji fallback). Use fictional/stock people. */
registerChallenge(3,{title:'Select all of the CEO\'s business partners',sub:'Verification',render(b,{pass,fail}){
  const people=shuffle([
    {k:1,n:'Brenda',r:'Co-founder',e:'👩‍🦳',ok:1},
    {k:2,n:'Todd',r:'Intern (unpaid)',e:'🧑‍💻',ok:1},
    {k:3,n:'Linda',r:'Wife',e:'👩',ok:0},
    {k:4,n:'Unnamed',r:'Mystery investor',e:'❓',ok:1},
    {k:5,n:'Gerald',r:'Rubber duck',e:'🦆',ok:1},
    {k:6,n:'Kyle',r:'Barista',e:'🧑‍🍳',ok:0},
    {k:7,n:'Carol',r:'His mom',e:'👵',ok:0},
    {k:8,n:'Priya',r:'Head of Sales',e:'👩‍💼',ok:1},
  ]);
  const mk=(imgSrc,emoji,label)=>{
    const t=el('button',{className:'tile'});
    const img=el('img',{src:imgSrc,alt:''});
    img.onerror=()=>img.replaceWith(el('span',{textContent:emoji}));
    t.append(img,el('div',{className:'cap',textContent:label}));
    return t;
  };
  const g=el('div',{className:'grid'});g.style.cssText='grid-template-columns:repeat(3,1fr);width:276px;margin:0 auto';
  const sel=new Set();let pi=0;
  for(let c=0;c<9;c++){
    if(c===4){const t=mk('img/03/ceo.jpg','🕴️','CEO');t.style.cursor='default';t.style.fontSize='52px';t.style.outline='3px solid #222';t.style.outlineOffset='-3px';g.append(t);continue}
    const i=pi++,p=people[i];
    const t=mk(`img/03/p${p.k}.jpg`,p.e,`${p.n} · ${p.r}`);
    t.onclick=()=>{sel.has(i)?sel.delete(i):sel.add(i);t.classList.toggle('sel')};
    g.append(t);
  }
  const btn=el('button',{className:'v',textContent:'Verify'});
  btn.onclick=()=>people.every((p,i)=>!!p.ok===sel.has(i))?pass():fail('Incorrect. Try again.');
  b.append(el('div',{className:'hint',textContent:'Select every business partner of the CEO in the middle.'}),g,btn);
}});
