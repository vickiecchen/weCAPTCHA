/* NN — your challenge name
 *
 * HOW TO USE
 *  1. Copy this file to challenges/NN-your-name.js  (NN = two-digit order, e.g. 10)
 *  2. Add ONE line in index.html before js/engine.js:
 *       <script src="challenges/NN-your-name.js"></script>
 *  3. Change the number in registerChallenge(NN, ...) below to match.
 *  4. Open index.html?level=NN&debug=1 to test just your challenge.
 *
 * RULES
 *  - Only touch your own file (and img/NN/ for images). Don't edit js/ or css/base.css.
 *  - Put challenge-specific CSS in the `css` string below. Prefix class names with your number (.c10-thing)
 *    so they can't clash with other people's.
 *  - render(body, {pass, fail}) fills `body` (a div). Call pass() when solved, fail('message') when wrong.
 *  - Optionally return a cleanup function (clear timers, remove elements added outside `body`).
 *  - Helpers available globally: $, el, rnd, shuffle, beep.
 *  - The question text goes in `title` (shown in the blue header). Don't repeat it in the white area.
 */
registerChallenge(99,{
  css:`
.c99-btn{font-size:20px;padding:20px}
`,
  title:'Click the button',
  sub:'Verification',
  render(body,{pass,fail}){
    const btn=el('button',{className:'v c99-btn',textContent:'I am a human'});
    btn.onclick=()=>pass();
    body.append(btn);
    return()=>{/* cleanup if needed */};
  }
});
