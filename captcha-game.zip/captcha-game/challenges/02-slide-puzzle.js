/* 2 — slide the puzzle (EASY) */
registerChallenge(2,{
  css:`
input[type=range]{width:100%;margin-top:14px;height:34px;accent-color:var(--blue)}
`,
  title:'Slide to complete the puzzle',sub:'Verification',render(b,{pass,fail}){
  const W=340,H=180,S=40;
  const bg=document.createElement('canvas');bg.width=W;bg.height=H;const g=bg.getContext('2d');
  const gr=g.createLinearGradient(0,0,0,H);gr.addColorStop(0,'#5fa8e6');gr.addColorStop(.55,'#dcebf7');gr.addColorStop(.56,'#2c3e50');gr.addColorStop(1,'#16212c');
  g.fillStyle=gr;g.fillRect(0,0,W,H);
  g.fillStyle='rgba(255,255,255,.92)';[[40,35],[150,25],[250,48]].forEach(([cx,cy])=>{for(let i=0;i<4;i++){g.beginPath();g.arc(cx+i*14,cy+(i%2)*6,16,0,7);g.fill()}});
  g.fillStyle='#3a4a5a';g.beginPath();g.moveTo(W/2-5,H*.56);g.lineTo(W/2+5,H*.56);g.lineTo(W,H);g.lineTo(0,H);g.fill();
  g.strokeStyle='#fff';g.lineWidth=3;g.setLineDash([14,12]);g.beginPath();g.moveTo(W/2,H*.56);g.lineTo(W/2,H);g.stroke();
  const tx=rnd(150,270),ty=rnd(50,110);
  const P=(px,py)=>{const p=new Path2D();p.rect(px,py,S,S);p.arc(px+S/2,py-5,7,0,Math.PI*2);return p};
  const c=el('canvas',{width:W,height:H});c.style.cssText='width:100%;border:1px solid #ccc;display:block';
  const x=c.getContext('2d');
  const draw=px=>{x.clearRect(0,0,W,H);x.drawImage(bg,0,0);x.fillStyle='rgba(0,0,0,.55)';x.fill(P(tx,ty));
    x.save();x.clip(P(px,ty));x.drawImage(bg,px-tx,0);x.restore();x.strokeStyle='#fff';x.lineWidth=2;x.stroke(P(px,ty))};
  const posOf=v=>8+v/100*(W-S-16);
  draw(posOf(0));
  const sl=el('input',{type:'range',min:0,max:100,value:0,step:.1});
  sl.oninput=()=>draw(posOf(+sl.value));
  sl.onchange=()=>Math.abs(posOf(+sl.value)-tx)<=4?pass():fail('Incorrect. Try again.');
  b.append(c,sl,el('div',{className:'hint',textContent:'Drag the slider to fit the puzzle piece'}));
}});
