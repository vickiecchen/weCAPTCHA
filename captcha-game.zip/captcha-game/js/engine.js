const LEVELS=CHALLENGES.sort((a,b)=>a.n-b.n);

/* ================= ENGINE ================= */
let cur=0,cleanup=null,locked=false;
function showMsg(t){const m=$('#msg');m.textContent=t;m.classList.add('on');setTimeout(()=>m.classList.remove('on'),900)}
function load(i){
  if(cleanup){cleanup();cleanup=null}
  locked=false;
  cur=Math.max(0,Math.min(LEVELS.length-1,i));
  const L=LEVELS[cur];
  $('#title').textContent=L.title;$('#sub').textContent=L.sub||'';
  const body=$('#body');body.innerHTML='';
  cleanup=L.render(body,{pass,fail})||null;
  dbgSync();
}
function pass(){
  if(locked)return;locked=true;beep(880,.12);
  $('#body').append(el('div',{className:'ok',textContent:'✓ Verified'}));
  setTimeout(()=>load(cur+1),550);
}
function fail(msg){
  if(locked)return;locked=true;beep(160,.25);
  const c=$('#card');c.classList.remove('shake');void c.offsetWidth;c.classList.add('shake');
  showMsg(msg||'Incorrect. Try again.');
  setTimeout(()=>load(cur),650);
}

/* ================= DEBUG MENU (press d, or open with ?debug=1) ================= */
const dbg=el('div',{id:'dbg'});
dbg.innerHTML='<b>DEBUG</b> <span id="dl"></span><div id="dlv"></div><div><button data-a="prev">◀ Prev</button><button data-a="next">Next ▶</button><button data-a="re">↻ Restart</button><button data-a="solve">✓ Solve</button><button data-a="hud">Footer</button></div><small>d menu · r restart · s solve · n/p next/prev · h footer · 1-9 jump</small>';
document.body.append(dbg);
LEVELS.forEach((_,i)=>{const bt=el('button',{textContent:i+1});bt.dataset.l=i;$('#dlv',dbg).append(bt)});
dbg.onclick=e=>{
  const t=e.target;if(t.tagName!=='BUTTON')return;
  if(t.dataset.l!==undefined)return load(+t.dataset.l);
  const a=t.dataset.a;
  if(a==='prev')load(cur-1);else if(a==='next')load(cur+1);else if(a==='re')load(cur);
  else if(a==='solve')solveNow();else if(a==='hud')document.body.classList.toggle('nohud');
};
function solveNow(){if(cur<LEVELS.length-1)pass()}
function dbgSync(){$('#dl',dbg).textContent=`level ${cur+1}/${LEVELS.length}`;[...$('#dlv',dbg).children].forEach((bt,i)=>bt.classList.toggle('cur',i===cur))}
dbgSync();
if(new URLSearchParams(location.search).get('debug'))dbg.classList.add('on');
addEventListener('keydown',e=>{
  if(e.target.tagName==='INPUT')return;
  if(/^[1-9]$/.test(e.key))load(+e.key-1);
  else if(e.key==='n')load(cur+1);
  else if(e.key==='p')load(cur-1);
  else if(e.key==='h')document.body.classList.toggle('nohud');
  else if(e.key==='d'||e.key==='`')dbg.classList.toggle('on');
  else if(e.key==='r')load(cur);
  else if(e.key==='s')solveNow();
});
const q=new URLSearchParams(location.search).get('level');
load(q?+q-1:0);
