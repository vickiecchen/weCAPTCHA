const $=(s,r=document)=>r.querySelector(s);
const el=(t,p={},...k)=>{const e=document.createElement(t);Object.assign(e,p);k.forEach(x=>e.append(x));return e};
const rnd=(a,b)=>Math.floor(Math.random()*(b-a+1))+a;
const shuffle=a=>{a=[...a];for(let i=a.length-1;i>0;i--){const j=rnd(0,i);[a[i],a[j]]=[a[j],a[i]]}return a};
let ac;const beep=(f,d)=>{try{ac=ac||new AudioContext();const o=ac.createOscillator(),g=ac.createGain();o.frequency.value=f;g.gain.value=.05;o.connect(g);g.connect(ac.destination);o.start();o.stop(ac.currentTime+d)}catch(e){}};

/* Challenges register themselves here. Each file in /challenges calls registerChallenge(order, {...}). */
const CHALLENGES=[];
function registerChallenge(n,def){
  def.n=n;CHALLENGES.push(def);
  if(def.css)document.head.append(el('style',{textContent:def.css}));
}
