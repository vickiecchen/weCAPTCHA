# Captcha Game

Open `index.html` in a browser. No install or server needed (or use the VS Code "Live Server" extension if you like auto-reload).

## Layout (one file per challenge)
```
index.html               shell + script tags (don't edit; one line per challenge)
css/base.css             shared styles
js/helpers.js            $, el, rnd, shuffle, beep, registerChallenge
js/engine.js             level loader, pass/fail, debug menu, key shortcuts
challenges/NN-name.js    ONE FILE PER CHALLENGE (this is where you work)
challenges/_template.js  copy this to start a new challenge (not loaded by the game)
img/03/  img/05/         images for challenges 3 and 5
```

| # | File | Owner |
|---|---|---|
| 1 | `01-type-text.js` (type the numbers) | |
| 2 | `02-slide-puzzle.js` | |
| 3 | `03-ceo-partners.js` | |
| 4 | `04-smallest-circle.js` | |
| 5 | `05-muffin-chihuahua.js` | |
| 6 | `06-which-heavier.js` | |
| 7 | `07-duck-pen.js` | |
| 8 | `08-are-you-human.js` | |
| 9 | `09-stupid-api.js` (disabled; set `ENABLED=true` inside to turn on) | |

## Working on your challenge
- Test just yours: `index.html?level=7&debug=1` (7 = your number).
- Only edit your own challenge file, plus `img/NN/` for its images. That keeps merges conflict-free.
- Challenge-specific CSS goes in that file's `css:` string. Shared look lives in `css/base.css`. Ask before changing it, since everyone uses it.
- Don't repeat the question in the white area. It's already in the blue header (`title`).

## Controls for testing and recording
- `?level=N` jumps to level N. `?debug=1` opens the debug menu.
- `d` toggles the debug menu (level jumps, Prev/Next, Restart, Solve, footer toggle).
- `r` restart level, `s` auto-solve, `n`/`p` next/prev, `1`-`9` jump, `h` toggle footer.
- Hide the debug menu (`d`) before recording.

## Images
Files are optional. If one is missing, an emoji shows instead. Use .jpg, square-ish.
- Challenge 3 (`img/03/`): `ceo.jpg` (middle), `p1.jpg` Brenda (partner), `p2.jpg` Todd (partner), `p3.jpg` Linda/wife (NOT), `p4.jpg` unnamed investor (partner), `p5.jpg` Gerald/duck (partner), `p6.jpg` Kyle/barista (NOT), `p7.jpg` Carol/his mom (NOT), `p8.jpg` Priya (partner). Use stock photos, teammates or illustrations, not real public figures.
- Challenge 5 (`img/05/`): `chi1.jpg`-`chi8.jpg` (chihuahuas) and `muffin1.jpg`-`muffin8.jpg` (blueberry muffins).

## Answers (for testing)
1. Type the 4 digits shown. 2. Slide piece into the hole (within ~4px). 3. Brenda, Todd, Priya, Unnamed, Gerald.
4. Drag the yellow blob away, click the tiny circle. 5. Select all chihuahuas. 6. Squirrel.
7. Ducks start in the pen then escape. Drag all 12 back in. 8. Chase the button (dodges 3/5/7/10 times), then click. 9. Empty for now.

## Git workflow (suggested)
- `main` always works. Each person: `git checkout -b challenge-07-ducks`, commit only their files, open a PR (or merge when it works).
- Pull `main` before you start and before you merge.
- Adding a brand-new challenge = one new file + one new `<script>` line in `index.html` (merge both lines if two people add at once).
